console.log(Buffer.byteLength(null));
